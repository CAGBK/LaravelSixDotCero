<script type="text/javascript">
    $(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script><?php /**PATH C:\Users\dsgut\OneDrive\Escritorio\LaravelSixDotCero\vendor\jeremykenedy\laravel-logger\src/resources/views//scripts/tooltip.blade.php ENDPATH**/ ?>