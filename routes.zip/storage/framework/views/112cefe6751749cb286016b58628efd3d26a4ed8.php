<script type="text/javascript">
    $(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script><?php /**PATH C:\Users\ca.gonzalezb1\Desktop\LaravelSixDotCero\vendor\jeremykenedy\laravel-logger\src/resources/views//scripts/tooltip.blade.php ENDPATH**/ ?>