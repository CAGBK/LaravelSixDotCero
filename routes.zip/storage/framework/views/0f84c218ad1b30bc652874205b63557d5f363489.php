<?php echo e($slot); ?>

<?php /**PATH C:\Users\dsgut\OneDrive\Escritorio\LaravelSixDotCero\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>