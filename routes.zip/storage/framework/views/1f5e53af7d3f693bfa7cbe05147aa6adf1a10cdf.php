<script type="text/javascript">
    $(function() {
        $(".clickable-row").click(function() {
            window.location = $(this).data("href");
        });
    });
</script><?php /**PATH C:\Users\d.gutierrezg\Desktop\LaravelSixDotCero\vendor\jeremykenedy\laravel-logger\src/resources/views//scripts/clickable-row.blade.php ENDPATH**/ ?>