<script type="text/javascript">

	function markNotificationAsRead()
	{
		$.get('/markAsRead');
	}
	
</script>	
 
